
import React, { createContext, useContext, useState, useEffect } from 'react';
import { PRODUCTS, CATEGORIES, ADVANTAGES, MATERIALS } from '../constants';

interface Message {
  id: string;
  role: 'user' | 'admin';
  text: string;
  timestamp: string;
}

interface ChatSession {
  id: string;
  userName: string;
  lastMessage: string;
  messages: Message[];
  isRead: boolean;
}

interface DataContextType {
  products: any[];
  categories: any[];
  materials: any[];
  leads: any[];
  chats: ChatSession[];
  dbStatus: 'local' | 'syncing' | 'connected';
  updateProduct: (id: string, updates: any) => void;
  addProduct: (product: any) => void;
  deleteProduct: (id: string) => void;
  updateCategory: (id: string, updates: any) => void;
  addLead: (lead: any, botField?: string) => boolean;
  deleteLead: (id: string) => void;
  sendChatMessage: (sessionId: string, text: string, role: 'user' | 'admin') => boolean;
  markChatAsRead: (sessionId: string) => void;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState(PRODUCTS);
  const [categories, setCategories] = useState(CATEGORIES);
  const [materials, setMaterials] = useState(MATERIALS);
  const [leads, setLeads] = useState<any[]>([]);
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [dbStatus, setDbStatus] = useState<'local' | 'syncing' | 'connected'>('local');
  const [lastActionTime, setLastActionTime] = useState(0);

  // Load from LocalStorage
  useEffect(() => {
    const savedLeads = localStorage.getItem('lm_leads');
    const savedChats = localStorage.getItem('lm_chats');
    const savedProducts = localStorage.getItem('lm_products');
    
    if (savedLeads) setLeads(JSON.parse(savedLeads));
    if (savedChats) setChats(JSON.parse(savedChats));
    if (savedProducts) setProducts(JSON.parse(savedProducts));
  }, []);

  // Save to LocalStorage (as fallback)
  useEffect(() => {
    localStorage.setItem('lm_leads', JSON.stringify(leads));
    localStorage.setItem('lm_chats', JSON.stringify(chats));
    localStorage.setItem('lm_products', JSON.stringify(products));
  }, [leads, chats, products]);

  const isRateLimited = () => {
    const now = Date.now();
    if (now - lastActionTime < 2000) return true;
    setLastActionTime(now);
    return false;
  };

  // Функция для дублирования сообщения на почту
  const notifyByEmail = async (sessionId: string, text: string) => {
    try {
      // Используем Formspree или аналогичный сервис для отправки без бэкенда
      // В реальном проекте здесь будет вызов вашего API эндпоинта
      await fetch("https://formspree.io/f/mqakevve", { // MQAKEVVE - пример ID, замените на свой при деплое
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          _to: "gyakovg11@gmail.com",
          subject: "Новое сообщение в чате ThelMebel",
          visitor: sessionId,
          message: text,
          timestamp: new Date().toLocaleString()
        })
      });
      console.log("Email notification sent to gyakovg11@gmail.com");
    } catch (error) {
      console.error("Failed to send email notification:", error);
    }
  };

  const updateProduct = (id: string, updates: any) => setProducts(p => p.map(x => x.id === id ? { ...x, ...updates } : x));
  const addProduct = (p: any) => setProducts(prev => [p, ...prev]);
  const deleteProduct = (id: string) => setProducts(p => p.filter(x => x.id !== id));
  const updateCategory = (id: string, updates: any) => setCategories(c => c.map(x => x.id === id ? { ...x, ...updates } : x));
  
  const addLead = (lead: any, botField?: string) => {
    if (botField) return false;
    if (isRateLimited()) return false;

    const newLead = { ...lead, id: Date.now().toString(), date: new Date().toLocaleString() };
    setLeads(prev => [newLead, ...prev]);
    
    // Дублируем заявку на почту
    notifyByEmail("NEW_LEAD", `Телефон: ${lead.phone}`);
    
    return true;
  };

  const deleteLead = (id: string) => setLeads(l => l.filter(x => x.id !== id));

  const sendChatMessage = (sessionId: string, text: string, role: 'user' | 'admin') => {
    if (role === 'user' && isRateLimited()) return false;

    setChats(prev => {
      const existing = prev.find(s => s.id === sessionId);
      const newMessage: Message = {
        id: Date.now().toString(),
        role,
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      if (role === 'user') {
        notifyByEmail(sessionId, text);
      }

      if (existing) {
        return prev.map(s => s.id === sessionId ? {
          ...s,
          lastMessage: text,
          messages: [...s.messages, newMessage],
          isRead: role === 'admin'
        } : s);
      } else {
        return [{
          id: sessionId,
          userName: `Клиент ${sessionId.slice(-4)}`,
          lastMessage: text,
          messages: [newMessage],
          isRead: false
        }, ...prev];
      }
    });
    return true;
  };

  const markChatAsRead = (sessionId: string) => {
    setChats(prev => prev.map(s => s.id === sessionId ? { ...s, isRead: true } : s));
  };

  return (
    <DataContext.Provider value={{ 
      products, categories, materials, leads, chats, dbStatus,
      updateProduct, addProduct, deleteProduct,
      updateCategory, addLead, deleteLead,
      sendChatMessage, markChatAsRead,
      isAdmin, setIsAdmin 
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
};
